<?php
// Prevent direct access to directory listing
// This file should never be executed directly
exit;
